package br.com.agencia.newcity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewCityApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewCityApplication.class, args);
	}

}
