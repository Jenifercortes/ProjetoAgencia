package com.arjuncodes.springbootcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
