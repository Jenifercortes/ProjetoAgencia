package com.jenifer.api.repositories;

public interface ProdutoRepository extends JPAR{

}
